<?php
include_once (dirname(__FILE__) . '/API_drag-n-drop.php');

if(isset($_POST['myLayout'])){
	
	cookie_creator( $_POST['myLayout'] );
}

if(isset($_POST['add'])){
	
	add_new_widget( $_POST['add'] );
}

if(isset($_GET['reset'])){
	
	cookie_remover();
	header('Location:'.PAGE_URL);
}
/*
At this time I only save the widget layout on cookie.
If you like to store this cookie value on DB all you have to do just create
new function to heandle store process (if you familiar with php it should be quite easy)
*/
?>