/*
 * Original Script from NETTUTS.com [by James Padolsey]
 * @requires jQuery($), jQuery UI & sortable/draggable UI modules
 * This xhtpr.js file from kandar.info writen by kandar (iskandarsoesman@gmail.com) @ 5 March 2009
 */
 
var xmlHttp = createXmlHttpRequest();
var obj = '';

function createXmlHttpRequest() {
  var xmlHttp = false;
  if (window.ActiveXObject) {
    xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
  } else {
    xmlHttp = new XMLHttpRequest();
  }
  if (!xmlHttp) {
    alert("Ops sorry We found some error!!");
  }
  return xmlHttp;
}


function postData(source,values) {
  // Process for complited object (code = 4)
  // Or not initial yet (code = 0)
  if (xmlHttp.readyState == 4 || xmlHttp.readyState == 0) {
	
    xmlHttp.open("POST", source, true);
    
	xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlHttp.setRequestHeader("Content-length", values.length);
	xmlHttp.setRequestHeader("Connection", "close");

    xmlHttp.send(values);
  } else {
    setTimeout('postData(source)', 100000);
  }
}


function getData(source, divID) {
  if (xmlHttp.readyState == 4 || xmlHttp.readyState == 0) {
    obj = divID;
	
    xmlHttp.open("GET", source);
	
    xmlHttp.onreadystatechange = handleRespon;
    xmlHttp.send(null);
  } else {
   
    setTimeout('getData(source, divID)', 100000);
  }
}


function handleRespon() {
  if (xmlHttp.readyState == 4) {
    // Jika kode respon HTTP = 200 (OK)
    if (xmlHttp.status == 200) {
      // Set teks
      document.getElementById(obj).innerHTML = xmlHttp.responseText;
    } else {
      alert("Error: " + xmlHttp.statusText);
    }
  }
  else{
	document.getElementById(obj).innerHTML = '<div style="padding-top:50px; padding-bottom:90px; text-align:center;"><img src="ajax-loader.gif"></div>';
  }
}

function add(id){
	postData('res.php', 'add=' + id);
}