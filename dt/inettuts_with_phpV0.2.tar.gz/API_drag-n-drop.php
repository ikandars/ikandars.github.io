<?php
/*
This API drag and drop originally writen by kandar (iskandarsoesman@gmail.com) @ March, 5 2009
for suttable with inettuts. Inettus grad and drop aplication origianlly writen by James Padolsey (http://net.tutsplus.com/tutorials/javascript-ajax/inettuts/)

How this API store informatin to cookie are litile bit diferent with what James have on inettuts V.2 (http://james.padolsey.com/javascript/inettuts-with-cookies/)
Insteed using Javascript to create cookie, I prefer using PHP to do that.
I used Ajax method to heandle this proccess.
I hope this API could make more easy for those who wan to store in DB.

LIMITATION:
This version not save collapsed/un collapsed
*/
define('PAGE_URL', 'http://www.kandar.info/inettuts-with-php/');

$widget_1 = 'widget1,color-green,Introduction Widget,not-collapsed';
$widget_2 = 'widget2,color-red,Widget title,not-collapsed';
$widget_3 = 'widget3,color-blue,Widget title,not-collapsed';
$widget_4 = 'widget4,color-yellow,Widget title,not-collapsed';
$widget_5 = 'widget5,color-orange,Widget title,not-collapsed';
$widget_6 = 'widget6,color-white,Widget title,not-collapsed';

$widgets = array(
		$widget_1,
		$widget_2,
		$widget_3,
		$widget_4,
		$widget_5,
		$widget_6
	);

//default position if no cookie is set
$default_widget_position = $widgets[0].'|'.$widgets[2].'|'.$widgets[4];

function clumns( $id ){
	global $widgets, $default_widget_position;
	
	if( !isset($_COOKIE['inettus_layout']) ){
		
		$position = $default_widget_position;
		
	}
	else{
		
		$position = $_COOKIE['inettus_layout'];
	}

	$explode_columns = explode('|', $position);

	$column_1 = $explode_columns[0];
	$column_2 = $explode_columns[1];
	$column_3 = $explode_columns[2];

	//explode column 1 containt
	if( $id == 1){
		
		$explode_column_1 = explode(';',$column_1);
		$count_widget = count($explode_column_1);
		
		if(!empty($explode_columns[0])){
			
			for ($i=0; $i<=$count_widget-1; ++$i){
				
				$widget_value_col_1 = explode(',',$explode_column_1[$i]);
				
				$widget_id = $widget_value_col_1[0];
				$widget_color = $widget_value_col_1[1];
				$widget_title = $widget_value_col_1[2];
				$widget_collapsed = $widget_value_col_1[3];
				
				printf( widget($widget_color, $widget_title, $widget_id) );
			}
		}
	}//end column 1
	//explode column 2 containt
	else if( $id == 2){
		
		$explode_column_2 = explode(';',$column_2);
		$count_widget = count($explode_column_2);
		
		if(!empty($explode_columns[1])){
			
			for ($i=0; $i<=$count_widget-1; ++$i){
				
				$widget_value_col_2 = explode(',',$explode_column_2[$i]);
				
				$widget_id = $widget_value_col_2[0];
				$widget_color = $widget_value_col_2[1];
				$widget_title = $widget_value_col_2[2];
				$widget_collapsed = $widget_value_col_2[3];
				
				printf( widget($widget_color, $widget_title, $widget_id) );
			}
		}
	}//end column 2
	//explode column 3 containt
	else if( $id == 3){
		
		$explode_column_3 = explode(';',$column_3);
		$count_widget = count($explode_column_3);
		
		if(!empty($explode_columns[2])){
			
			for ($i=0; $i<=$count_widget-1; ++$i){
				
				$widget_value_col_3 = explode(',',$explode_column_3[$i]);
				
				$widget_id = $widget_value_col_3[0];
				$widget_color = $widget_value_col_3[1];
				$widget_title = $widget_value_col_3[2];
				$widget_collapsed = $widget_value_col_3[3];
				
				printf( widget($widget_color, $widget_title, $widget_id) );
			}
		}
	}//end column 3
}

function widget($color, $title, $id){
	
	$widget = '<li class="widget '.$color.'" id="'.$id.'">  
						<div class="widget-head">
							<h3>'.$title.'</h3>
						</div>
						<div class="widget-content">
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aliquam magna sem, fringilla in, commodo a, rutrum ut, massa. Donec id nibh eu dui auctor tempor. Morbi laoreet eleifend dolor. Suspendisse pede odio, accumsan vitae, auctor non, suscipit at, ipsum. Cras varius sapien vel lectus.</p>
							</div>
					</li>';
	
	return $widget;
}


function cookie_creator( $value ){
	
	setcookie('inettus_layout', $value, time()+31536000, '', '');
}

function cookie_remover(){
	
	setcookie('inettus_layout', $value, time()-31536000, '', '');
}

function add_new_widget( $widget_id ){
	global $widgets, $default_widget_position;
	
	if( !isset($_COOKIE['inettus_layout']) ){
		//default position if no cookie is set plus new widget
		$position = $widgets[$widget_id].';'.$default_widget_position;
		
	}
	else{
		
		$position = $widgets[$widget_id].';'.$_COOKIE['inettus_layout'];
	}
	cookie_creator($position);
}

function widget_checker( $name ){
	global $default_widget_position;
	
	if( !isset($_COOKIE['inettus_layout']) ){
		
		$position = $default_widget_position;
		
	}
	else{
		
		$position = $_COOKIE['inettus_layout'];
	}
	
	if(eregi($name, $position)){
		
		return true;
	}
	else{
		
		return false;
	}
	
}

function widget_menu(){
	
	if( widget_checker('widget1') == false ){
		
		$w1 = '<input name="cb1" value="test" type="checkbox" onMouseDown="add('."'".'0'."'".');">Add Green Widget';
	}
	
	if( widget_checker('widget2') == false ){
		
		$w2 = '<input name="cb1" value="test" type="checkbox" onMouseDown="add('."'".'1'."'".');"> Add Red Widget';
	}
	
	if( widget_checker('widget3') == false ){
		
		$w3 = '<input name="cb1" value="test" type="checkbox" onMouseDown="add('."'".'2'."'".');"> Add Blue Widget';
	}
	
	if( widget_checker('widget4') == false ){
		
		$w4 = '<input name="cb1" value="test" type="checkbox" onMouseDown="add('."'".'3'."'".');" href="#"> Add Yellow Widget';
	}
	
	if( widget_checker('widget5') == false ){
		
		$w5 = '<input name="cb1" value="test" type="checkbox" onMouseDown="add('."'".'4'."'".');"> Add Orange Widget';
	}
	
	if( widget_checker('widget6') == false ){
		
		$w6 = '<input name="cb1" value="test" type="checkbox" onMouseDown="add('."'".'5'."'".');"> Add White Widget';
	}
	
	if(!isset($w1) && !isset($w2) && !isset($w3) && !isset($w4) && !isset($w5) && !isset($w6)){
		
		return '<p>You have all widgets on your page.</p><p><input id="Login" type="submit" onclick="tb_remove()" value="Ok"/></p>';
		
	}
	else{
		
		return '<p>'.$w1.' '.$w2.' '.$w3.'</p><p>'.$w4.' '.$w5.' '.$w6.'</p><br /><p><a href="'.PAGE_URL.'"><input type="button" value="See My Page"></a></p>';
	}

}

/*
You can add database function here so you can store the widget layout on database
*/
?>