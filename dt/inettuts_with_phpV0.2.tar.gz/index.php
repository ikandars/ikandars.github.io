<?php
include_once (dirname(__FILE__) . '/API_drag-n-drop.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Welcome to iNettuts</title>
<link href="inettuts.css" rel="stylesheet" type="text/css" />
<link href="thickbox.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="xhttpr.js"></script>

</head>
<body>
    
    <div id="head">
        <h1>iNettuts</h1>
		<a href="add.php?height=220&width=400" class="thickbox" title="Add New Widget">Add Widgets</a> <a href="res.php?reset">Reset to defalut</a>
		</div>

    <div id="columns">
        
        <ul id="column1" class="column">
		
		<?php clumns(1);?>
        </ul>
		
        <ul id="column2" class="column">
		<?php clumns(2);?>
        </ul>
        
        <ul id="column3" class="column">
		<?php clumns(3);?>
		</ul>
        
    </div>
	
	
    <script type="text/javascript" src="jquery-1.2.6.min.js"></script>
	<script type="text/javascript" src="jquery-ui-personalized-1.6rc2.min.js"></script>
	<script type="text/javascript" src="inettuts.js"></script>
	<script type="text/javascript" src="thickbox.js"></script>
	

</body>
</html>