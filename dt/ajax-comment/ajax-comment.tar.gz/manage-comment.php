<?php
/*
This script writen and modified by kandar (iskandarsoesman@gmail.com) at April 2009
Feel free to modified with your own risk.
Visit my blog at www.kandar.info for more stuffs.
*/

include_once 'config.php';

$today_date	= date("d/m/Y H:i:s");

function insert_comment($name, $comment){
	global $db;
	
	$sql_date	= date("Y-m-d H:i:s");
	$sql		= $db->query("INSERT INTO comments (name, comment, date) VALUES('$name', '$comment', '$sql_date')");
	
	if($sql){
		
		//get this comment id from db
		$result = $db->query("SELECT id FROM comments WHERE date = '$sql_date'");
		$data = $result->fetch_array(MYSQLI_ASSOC);
		$comment_id = $data['id'];
		return $comment_id;
		
	}
	else{
		
		return false;
	}
}

function delete_comment($id){
	global $db;
	
	$delete = $db->query("DELETE FROM comments WHERE id = '$id'");
	
	if($delete){
		
		return true;
		
	}
	else{
		
		return false;
		
	}
}

if(isset($_POST['name'])){
	
	$name = htmlentities($_POST['name']);
	$comment = htmlentities($_POST['YourComment']);
	$id = rand(000,999);
	
	if(empty($name)){
		
		$alert = array('status'=>'0', 'message'=>'Silahkan isi nama anda.');
		$alert = json_encode($alert);
		exit($alert);
	}
	
	if(empty($comment)){
		
		$alert = array('status'=>'0', 'message'=>'Silahkan isi komentar anda.');
		$alert = json_encode($alert);
		exit($alert);
	}
	
	$insert_comment = insert_comment($name, $comment);
	
	$alert = array('status'=>'1', 'date'=>$today_date, 'name'=>$name, 'comment'=>$comment, 'message_id'=>$insert_comment);
	$alert = json_encode($alert);
	exit($alert);
}

if(isset($_POST['id'])){
	
	$delete = delete_comment($_POST['id']);
	
	if($delete == true){
		
		$alert = array('status'=>'1','id'=>$_POST['id']);
		$alert = json_encode($alert);
		exit($alert);
	}
	else{
		
		$alert = array('status'=>'0', 'message'=>'Error deleting comment.');
		$alert = json_encode($alert);
		exit($alert);
	}
}
?>