<?php
/*
This script writen and modified by kandar (iskandarsoesman@gmail.com) at April 2009
Feel free to modified with your own risk.
Visit my blog at www.kandar.info for more stuffs.
*/

$hot	= 'localhost';
$user	= 'your_db_user'; 	//change it with yours.
$pass	= '';				//filin your db password
$db_name= 'demo_ajax_comment';

$db		= new mysqli($host, $user, $pass, $db_name);
?>