<?php
/*
This script writen and modified by kandar (iskandarsoesman@gmail.com) at April 2009
Feel free to modified with your own risk.
Visit my blog at www.kandar.info for more stuffs.
*/

include_once 'config.php';

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>My Ajax Comment</title>
<script type="text/javascript">
/*
This script writen and modified by kandar (iskandarsoesman@gmail.com) at April 2009
Feel free to modified with your own risk.
Visit my blog at www.kandar.info for more stuffs.
*/

/* create ajax XmlHttpRequest */

var xmlHttp = createXmlHttpRequest();
var obj = '';

function createXmlHttpRequest() {
	var xmlHttp = false;
	if (window.ActiveXObject) {
		xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
	} else {
		xmlHttp = new XMLHttpRequest();
	}
	if (!xmlHttp) {
		alert("Ops sorry We found some error!!");
	}
	return xmlHttp;
}

/* function for send data thrugh post method */

function postAjax(source, values, respons, hanres) {
	
  if (xmlHttp.readyState == 4 || xmlHttp.readyState == 0) {
	
	obj = respons;
	
	xmlHttp.open("POST", source, true);
	
	xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlHttp.setRequestHeader("Content-length", values.length);
	xmlHttp.setRequestHeader("Connection", "close");
	xmlHttp.onreadystatechange = hanres;
	xmlHttp.send(values);
  } else {
	setTimeout('postAjax(source, values, respons, hanres)', 100000);
  }
}

/* functions for send and hendle respons for add new comment */

function postContent(){
	/* Query value that send to php.*/
	var commentValue = 'name=' + encodeURI( document.getElementById('name').value ) + '&YourComment=' + encodeURI( document.getElementById('YourComment').value );
	/*server side */
	var send_to = 'manage-comment.php';
	/*Div id for handle preloader image or errors.*/
	var respons = 'alert';
	postAjax(send_to, commentValue, respons, handleResponComment);
}

function handleResponComment(){
	if (xmlHttp.readyState == 4){
		if (xmlHttp.status == 200){
			/*I more prefer use json as response value from php*/
			var JSONRespons = eval('(' + xmlHttp.responseText + ')');
			if(JSONRespons.status == 1){
				/*
				* if inserting new commend succeed, then we call commentResponse function to show the new comment.
				*/
				commentResponse(JSONRespons);
			}
			else{
				/*when new comment appeared, we have to re-enabel the form by calling enableForm() function using onload image event*/
				document.getElementById(obj).innerHTML = JSONRespons.message + '<img src="ajax-loading.gif" width="0" height="0" onload="enableForm();">';
			}
		} else {
			/*Incase we found errors on trancaction proccess.*/
			document.getElementById(obj).innerHTML = 'Error: ' + xmlHttp.statusText;
		}
	}
	else{
		/*
		* After submit new comment, we heve to diasable the form to prevent from re-submitng by user.
		* Also, show the preloader image, so user know his comment is being proceed.
		*/
		document.getElementById(obj).innerHTML = '<img src="ajax-loading.gif">';
		document.getElementById('name').disabled=true;
		document.getElementById('YourComment').disabled=true;
		document.getElementById('submit').disabled=true;
	} 
}


function commentResponse(JSONRespons){
	/*get listed comments*/
	var current_contents = document.getElementById('CommentList').innerHTML;
	/*Listed comments plus new comment that submited by user and inserted to database. */
	var newComment = current_contents + '<div class="Comment" id="' + JSONRespons.message_id + '"><div class="Remove"><a href="javascript:deleteContent(' + JSONRespons.message_id + ');">Remove</a></div><div class="SenderName"><img src="ajax-loading.gif" width="0" height="0" onload="enableForm();">' + JSONRespons.name + '</div><div class="CommentDate">' + JSONRespons.date + '</div><div class="CommentContent">' + JSONRespons.comment + '</div></div>'; 
	/*get current total comment */
	var currTotalComm = document.getElementById('numComment').innerHTML;
	/*current comment plus one */
	document.getElementById('numComment').innerHTML = parseInt(currTotalComm) + parseInt(1);
	/*show up the new listed comments*/
	document.getElementById('CommentList').innerHTML = newComment;
	/*reset the form*/
	document.getElementById('CommentForm').reset();
	/*remove the preloader image*/
	document.getElementById('alert').innerHTML = '';
}

function enableForm(){
	/*re-enable the form after all process done. */
	document.getElementById('name').disabled=false;
	document.getElementById('YourComment').disabled=false;
	document.getElementById('submit').disabled=false;
}

/* functions for send and hendle respons for delete a comment */

function deleteContent(messageID){
	var postValue = 'id=' + messageID;
	var send_to = 'manage-comment.php';
	var respons = 'alert';
	
	input_box = window.confirm('Are you sure want to delete this comment?');
	if (input_box==true){
		postAjax(send_to, postValue, respons, handleDeletedComment);
	}
}

function handleDeletedComment(){
	if (xmlHttp.readyState == 4){
		if (xmlHttp.status == 200){
			var JSONRespons = eval('(' + xmlHttp.responseText + ')');
			if(JSONRespons.status == 1){
				deleteNow(JSONRespons.id);
			}
			else{
				document.getElementById(obj).innerHTML = JSONRespons.message;
			}
		} else {
			document.getElementById(obj).innerHTML = 'Error: ' + xmlHttp.statusText;
		}
	}
}

function deleteNow(id){
	var delete_comment = document.getElementById(id);
	var currTotalComm = document.getElementById('numComment').innerHTML;
	document.getElementById('numComment').innerHTML = parseInt(currTotalComm) - parseInt(1);
	delete_comment.parentNode.removeChild(delete_comment);
	enableForm();
	document.getElementById('alert').innerHTML = '';
}
</script>
<style type="text/css">
body {margin-left: 10px;margin-top: 10px;margin-right: 10px;margin-bottom: 0px;padding:0px;font-family:Arial, Helvetica, sans-serif;font-size:12px;}
.Comment {border-bottom:1px solid #3686b8;}
#CommentList {width:350px;}
.totalComment {margin-top:10px;}
.cssform p{width: 300px;clear: left;margin: 0;padding: 5px 0 8px 0; padding-left: 50px;}
.cssform label{font-weight: bold;float: left; margin-left: -50px; width: 80px;}
.cssform input[type="text"]{width: 220px; border:1px solid #3686b8;}
.cssform textarea{width: 220px;height: 120px; border:1px solid #3686b8;}
.cssform input[type="submit"]{margin-left: 30px;}
.SenderName {font:bold 12px arial; padding: 3px;}
.CommentDate {padding: 3px;}
.CommentContent {padding: 3px;}
.Remove {float:right; padding: 3px;}
</style>
</head>
<body>

<div id="CommentList">
<!-- list start -->
<?php
$result = $db->query("SELECT id, name, comment, DATE_FORMAT(date, '%d/%m/%Y %H:%i:%s') AS local_date FROM comments");

while ($data = $result->fetch_object()){
?>
	<div class="Comment" id="<?php echo $data->id;?>">
	<div class="Remove"><a href="javascript:deleteContent(<?php echo $data->id;?>);">Remove</a></div>
	<div class="SenderName"><?php echo $data->name;?></div>
	<div class="CommentDate"><?php echo $data->local_date;?></div>
	<div class="CommentContent"><?php echo $data->comment;?></div>
	</div>
<?php
}
?>
<!--
<div class="Comment" id="1">
	<div class="SenderName">Kandar</div>
	<div class="CommentDate">23/04/2009 07:54:53</div>
	<div class="CommentContent">Ini komentar dari kandar</div>
</div>
<div class="Comment" id="2">
	<div class="SenderName">Foo</div>
	<div class="CommentDate">24/04/2009 22:54:00</div>
	<div class="CommentContent">hellow world</div>
</div>
<div class="Comment" id="3">
	<div class="SenderName">Mika Soesman</div>
	<div class="CommentDate">23/04/2009 18:54:23</div>
	<div class="CommentContent">Ini komentar dari kandar</div>
</div>
-->
<!--list end-->
</div>
<div class="totalComment">We have <span id="numComment"><?php echo $result->num_rows;?></span> comments at this time.</div>
<h3>Write Your Comment</h3>
<form name="CommentForm" id="CommentForm" class="cssform" action="javascript:postContent()" method="post" />
<p><label for="name">Name:</label> <input type="text" name="name" id="name" />
<p><label for="YourComment">Comment:</label> <textarea name="YourComment" id="YourComment" /></textarea></p>
<p><input name="Submit" id="submit" type="submit" value="Submit" /></p>
</form>
<div id="alert"></div>
</body>
</html>