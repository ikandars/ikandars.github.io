<?php
/**
 * PHP Comet with Nginx Http Push Module Handler
 *
 * @author <k4nar at yahoo dot com>
 */

// Set unlimited timeout
set_time_limit(0);

// Id channel
$channel_id             = '123';

// Private internal Nginx url
$nginx_url_publish      = 'http://localhost/broadcast/pub?channel='.$channel_id;
$nginx_url_subscribe    = 'http://localhost/broadcast/sub?channel='.$channel_id;


//Handler untuk requst publisher
if( isset($_POST['text']) && ! empty($_POST['text']) ){
    
    $request_headers = array(
        'Content-type: application/json; charset=UTF-8',
        'Accept: application/json'
    );
    
    $_POST['status'] = true;
    $response = send_request($nginx_url_publish, 'POST', json_encode($_POST), $request_headers  );
    
    header('Content-type: application/json');
    die( $response );
}


//Handler untuk requst subscriber
else {
    
    $request_headers = array(
        'Accept: application/json',
        'Connection: keep-alive',
        'Cache-Control: max-age=0'
    );
   
    if( ! $response = send_request($nginx_url_subscribe, 'GET', null, $request_headers) )
        $response = json_encode(array('status' => 'continue'));
    
    // Pastikan browser tidak men-cache halaman ini.
    header('Content-type: application/json');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Cache-Control: post-check=0, pre-check=0', FALSE);
    header('Pragma: no-cache');
    header('Last-Modified: ' . gmdate( 'D, j M Y H:i:s' ) . ' GMT' );
    
    die( $response );
}


/**
 * HTTP POST/GET requet menggunakan cUrl
 *
 * @param string $uri Alamat url akses API
 * @param string $method HTTP method POST | GET | PUT | DELETE
 * @param array $data Data yang dikirimkan pada saat melakukan request
 * @param array $request_headers Header string yang ingin ditambahkan saat melakukan request
 * @param bool $response_output_header Flag untuk menampilkan string header atau tidak
 * @param int $timeout Waktu maksimum hingga koneksi timeout
 * @return string jika berhasil atau false jika gagal
 */
function send_request( $uri, $method = 'GET', $data = array(), $request_headers = array(), $timeout = 30, $response_output_header = false ){

    $request_headers[]	= 'User-Agent: Comet Client/0.1';
    $method		= strtoupper($method);
    $url_separator	= ( parse_url( $uri, PHP_URL_QUERY ) ) ? '&' : '?';
    $uri		= ( $method == 'GET' && ! empty($data) ) ? $uri . $url_separator . http_build_query($data) : $uri;
    $c			= curl_init();
    
    curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($c, CURLOPT_URL, $uri);
    curl_setopt($c, CURLOPT_TIMEOUT, $timeout);
    
    if($response_output_header)
        curl_setopt($c, CURLOPT_HEADER, true);
    
    if( ! empty($data) && $method != 'GET' ) {
        
        if( is_array($data) )
            $data   = http_build_query($data);
        
        $request_headers[]  = 'Content-Length: ' . strlen($data);
        
        if( $method == 'POST' )
            curl_setopt($c, CURLOPT_POST, true);
        
        if( $method == 'PUT' || $method == 'DELETE' )
            curl_setopt($c, CURLOPT_CUSTOMREQUEST, $method);
        
        curl_setopt($c, CURLOPT_POSTFIELDS, $data);
    }
    
    curl_setopt($c, CURLOPT_HTTPHEADER, $request_headers);
    
    $contents = curl_exec($c);
    
    curl_close($c);
    
    if($contents)
        return $contents;
    
    return false;
}