<?php defined('THISPATH') or die('Can\'t access directly!');
/**
 * SSO OAuth2 Provider Sample Script
 *
 * @author Kandar <k4ndar at yahoo dot com>
 * @package SSO OAuth2 Sample
 * @category Client
 * @link http://www.kandar.info/index.php/php/mengengembangkan-single-sign-on-system-sso-menggunakan-oauth-2-0
 */

class Controller_user extends Panada {
    
    public function __construct(){
        
        parent::__construct();
        
        $this->db = new Library_db();
        $this->rest = new Library_rest();
        $this->request = new Library_request();
        $this->session = new Library_session(); 
        
    }
    
    public function index(){
        
        if( $this->session->get('is_provider_login') )
            $this->redirect('user/restricted_page');
        
        echo 'Anda belum login pada SSO Provider. Silahkan klik di <a href="user/signin">sini</a> untuk login.';
    }
    
    public function signin(){
        
        $error = null;
        $client_id = 'abcdef';
        $code = false;
        
        if( $this->request->get('client_id') ){
            $client_id = $this->request->get('client_id');
            $code = rand();
        }
        
        $redirect_uri = ( $this->request->get('redirect_uri') ) ? urldecode($this->request->get('redirect_uri')) : 'http://localhost/panada/user/restricted_page';
        $access_token = rand();
        $expires = strtotime('next hour');
        
        if( ! $this->session->get('is_provider_login') ) {
            
            if( $this->request->post('submit') ){
                
                if( $user = $this->db->get_row('users', array('username' => $this->request->post('username'), 'password' => md5($this->request->post('password'))) ) ) {
                    
                    $redirect_to = $this->recreate_url($redirect_uri, $code);
                    
                    $this->db->delete('access_privileges',
                                      array(
                                        'client_id' => $client_id,
                                        'user_id' => $user->id
                                        )
                                    );
                    
                    $this->db->insert('access_privileges',
                                      array(
                                        'client_id' => $client_id,
                                        'user_id' => $user->id,
                                        'code' => $code,
                                        'access_token' => $access_token,
                                        'redirect_uri' => $redirect_uri,
                                        'expires' => $expires
                                    )
                                );
                    
                    $this->session->set( array('is_provider_login' => $user->id, 'name' => $user->name) );
                    
                    $this->redirect( $redirect_to );
                }
                
                $error = '<p>Username atau password salah.</a>';
            }
            
            echo $error;
            echo '<form action="" method="post">';
            echo 'Username: <input type="text" name="username" /><br />';
            echo 'Password: <input type="password" name="password" /><br />';
            echo '<input type="submit" name="submit" value="Sign In" /><br />';
            echo '</form>';
        }
        else {
            
            if( $user = $this->db->get_row('users', array('id' => $this->session->get('is_provider_login')) ) ) {
                
                $redirect_to = $this->recreate_url($redirect_uri, $code);
                
                $this->db->delete('access_privileges',
                                      array(
                                        'client_id' => $client_id,
                                        'user_id' => $user->id
                                        )
                                    );
                    
                    $this->db->insert('access_privileges',
                                      array(
                                        'client_id' => $client_id,
                                        'user_id' => $user->id,
                                        'code' => $code,
                                        'access_token' => $access_token,
                                        'redirect_uri' => $redirect_uri,
                                        'expires' => $expires
                                    )
                                );
                
                $this->redirect($redirect_to);
            }
        }
    }
    
    public function recreate_url($url, $code = false){
        
        $parsed = parse_url($url);
        $query_args = array();
        
        if( isset($parsed['query']) )
            parse_str($parsed['query'], $query_args);
        
        if($code)
            $query_args['code'] = $code;
        
        $parsed['host'] = rtrim($parsed['host'], '/').'/';
        $redirect_to = $parsed['scheme'].'://'.$parsed['host'];
        
        if( isset($parsed['path']) )
            $redirect_to .= ltrim($parsed['path'], '/');
        
        $redirect_to .= '?'.http_build_query( $query_args );
        
        return $redirect_to;
    }
    
    public function restricted_page(){
        
        if( $this->session->get('is_provider_login') )
            echo 'Hallo <b>'.$this->session->get('name').'</b> Saat ini Anda sudah login di OAuth Provider | <a href="signout">Sign Out</a>';
        else
            $this->redirect('user');
    }
    
    public function signout(){
        
        $this->session->session_clear_all();
        
        $clients = $this->db->get_results('apps_clients');
        
        foreach($clients as $clients)
            echo '<img src="'.$clients->logout_url.'" width="0" height="0" alt="" />';
        
        if( ! $redirect_to = $this->request->get('redirect_to') )
            $redirect_to = 'http://localhost/panada/user';
        
        echo '<meta http-equiv="refresh" content="0; url=&#39;'.$redirect_to.'&#39;">';
    }
    
    public function access_token(){
        
        $code = $this->request->get('code');
        $client_id = $this->request->get('client_id');
        $client_secret = $this->request->get('client_secret');
        $redirect_uri = $this->request->get('redirect_uri');
        
        $data = (array) $this->db->row("SELECT
                                    access_privileges.access_token, access_privileges.expires
                                FROM
                                    access_privileges, apps_clients
                                WHERE
                                    apps_clients.client_id = access_privileges.client_id AND
                                    apps_clients.client_id = '$client_id' AND
                                    apps_clients.client_secret = '$client_secret' AND
                                    access_privileges.redirect_uri = '$redirect_uri' AND
                                    access_privileges.code = '$code'
                                    
                            ");
        
        if( ! $data )
            $data['error'] = 'Argument query yang Anda berikan tidak cocok.';
        
        echo urldecode(http_build_query($data));
    }
    
    public function get_data(){
        
        $access_token = $this->request->get('access_token');
        
        $data = $this->db->row("
                            SELECT
                                users.id, users.username, users.name
                            FROM
                                access_privileges, users
                            WHERE
                                users.id = access_privileges.user_id AND
                                access_privileges.access_token = '$access_token'
                        ");
        
        if( ! $data )
            $data['error'] = 'Argument query yang Anda berikan tidak cocok.';
        
        echo $this->rest->wrap_response_output($data, 'javascript');
        
    }
    
    public function redirector(){
        
        header("Content-type: text/javascript");
        
        if( $this->session->get('is_provider_login') )
            echo 'top.location.href=" http://localhost/panada/user/signin?client_id=c4ca4238a0b923820dcc509a6f75849b&redirect_uri=http://localhost/panada/auth/callback";';
        
    }
}