<?php defined('THISPATH') or die('Can\'t access directly!');
/**
 * SSO OAuth2 Client Sample Script
 *
 * @author Kandar <k4ndar at yahoo dot com>
 * @package SSO OAuth2 Sample
 * @category Client
 * @link http://www.kandar.info/index.php/php/mengengembangkan-single-sign-on-system-sso-menggunakan-oauth-2-0
 */

class Controller_auth extends Panada {
    
    public function __construct(){
        
        parent::__construct();
        
        $this->rest = new Library_rest();
        $this->oauth2_client = new Library_oauth2_client();
        $this->session = new Library_session(); 
        
        $this->oauth2_client->client_id = 'c4ca4238a0b923820dcc509a6f75849b';
        $this->oauth2_client->client_secret = '4fc9b72a83a99a594d40b3971874a9be';
        $this->oauth2_client->redirect_uri = 'http://localhost/panada/auth/callback';
    }
    
    public function index(){
        
        if( $this->session->get('is_login') )
            $this->redirect('auth/restricted_page');
        
        echo 'Anda berada pada aplikasi SSO client dan saat ini belum login. Klik <a href="auth/login">Sign In</a> untuk login.';
        echo '<script type="text/javascript" src="http://localhost/panada/user/redirector"></script>';
    }
    
    public function login(){
        
        $provider_auth_uri = 'http://localhost/panada/user/signin';
        
        $more_args = array( 'scope' => 'email', 'signin' => 'true' );
        
        $this->oauth2_client->user_authentication( $provider_auth_uri, $more_args );
    }
    
    public function callback(){
        
        $code = $_GET['code'];
        $provider_token_uri = 'http://localhost/panada/user/access_token';
        
        $response = $this->oauth2_client->get_access_token( $provider_token_uri, $code, 'GET', array('access_token' => 'true') );
        
        parse_str($response);
        
        $provider_uri = 'http://localhost/panada/user/get_data';
        
        $response = $this->oauth2_client->access_user_resources( $provider_uri, $access_token, 'GET', array('get_data' => 'true') );
        
        $data = json_decode( $response );
        
        $this->session->set(
            array(
                'is_login' => 1,
                'name' => $data->name,
                'id' => $data->id,
            )
        );
        
        $this->redirect('auth/restricted_page');
    }
    
    public function restricted_page(){
        
        if( ! $this->session->get('is_login') )
            $this->redirect('auth');
        
        echo 'Selamat datang <b>' . $this->session->get('name') . '</b> | <a href="'.$this->location('auth/signout').'">Sign Out</a>';
    }
    
    public function self_logout(){
        $this->session->session_clear_all();
    }
    
    public function signout(){
        
        $this->self_logout();
        
        $this->redirect('http://localhost/panada/auth');
    }
}