<?php
/*
This API drag and drop originally writen by kandar (iskandarsoesman@gmail.com) @ March, 5 2009
for suttable with inettuts. Inettus grad and drop aplication origianlly writen by James Padolsey (http://net.tutsplus.com/tutorials/javascript-ajax/inettuts/)

How this API store informatin to cookie are litile bit diferent with what James have on inettuts V.2 (http://james.padolsey.com/javascript/inettuts-with-cookies/)
Insteed using Javascript to create cookie, I prefer using PHP to do that.
I used Ajax method to heandle this proccess.
I hope this API could make more easy for those who wan to store in DB.

LIMITATION:
This version not save color changes and collapsed/un collapsed
*/

$widget_1 = widget('green', 'Introduction Widget', 'widget1');
$widget_2 = widget('red', 'Widget title', 'widget2');
$widget_3 = widget('blue', 'Widget title', 'widget3');
$widget_4 = widget('yellow', 'Widget title', 'widget4');
$widget_5 = widget('orange', 'Widget title', 'widget5');
$widget_6 = widget('white', 'Widget title', 'widget6');

$widgets = array(
		'widget1' => $widget_1,
		'widget2' => $widget_2,
		'widget3' => $widget_3,
		'widget4' => $widget_4,
		'widget5' => $widget_5,
		'widget6' => $widget_6
	);

function clumns( $id ){
	global $widgets;
	
	if( !isset($_COOKIE['inettus_layout']) ){
		
		$position = 'widget1,widget2,|widget3,widget4,|widget5,widget6,';
		
	}
	else{
		
		$position = $_COOKIE['inettus_layout'];
	}

	$explode_columns = explode('|', $position);

	$column_1 = $explode_columns[0];
	$column_2 = $explode_columns[1];
	$column_3 = $explode_columns[2];

	//explode column 1 containt
	if( $id == 1){
		
		$explode_column_1 = explode(',',$column_1);
		$count_widget = ( count($explode_column_1) - 1 );
		
		if($count_widget > 0){
			
			for ($i=0; $i<=$count_widget; ++$i){
				
				$widget_id = $explode_column_1[$i];
				
				printf( $widgets[$widget_id] );
			}
		}
	}//end column 1
	//explode column 2 containt
	else if( $id == 2){
		
		$explode_column_2 = explode(',',$column_2);
		$count_widget = ( count($explode_column_2) - 1 );
		
		if($count_widget > 0){
			
			for ($i=0; $i<=$count_widget; ++$i){
				
				$widget_id = $explode_column_2[$i];
				
				printf( $widgets[$widget_id] );
			}
		}
	}//end column 2
	//explode column 3 containt
	else if( $id == 3){
		
		$explode_column_3 = explode(',',$column_3);
		$count_widget = ( count($explode_column_3) - 1 );
		
		if($count_widget > 0){
			
			for ($i=0; $i<=$count_widget; ++$i){
				
				$widget_id = $explode_column_3[$i];
				
				printf( $widgets[$widget_id] );
			}
		}
	}//end column 3
}

function widget($color, $title, $id){

	$widget = '<li class="widget color-'.$color.'" id="'.$id.'">  
						<div class="widget-head">
							<h3>'.$title.'</h3>
						</div>
						<div class="widget-content">
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aliquam magna sem, fringilla in, commodo a, rutrum ut, massa. Donec id nibh eu dui auctor tempor. Morbi laoreet eleifend dolor. Suspendisse pede odio, accumsan vitae, auctor non, suscipit at, ipsum. Cras varius sapien vel lectus.</p>
						</div>
					</li>';
	
	return $widget;
}


function cookie_creator( $value ){
	
	setcookie('inettus_layout', $value, time()+31536000, '', '');
}

/*
You can add database function here so you can store the widget layout on database
*/
?>