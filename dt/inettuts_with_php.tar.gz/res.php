<?php
include_once (dirname(__FILE__) . '/API_drag-n-drop.php');

cookie_creator( $_POST['myLayout'] );
/*
At this time I only save the widget layout on cookie.
If you like to store this cookie value on DB all you have to do just create
new function to heandle store process (if you familiar with php it should be quite easy)
*/
?>