<?php
/*
This script writen and modified by kandar (iskandarsoesman@gmail.com) at August 2009
Feel free to modified with your own risk.
Visit my blog at www.kandar.info for more stuffs.

Original soruce writen by JanRain
(http://www.openidenabled.com/openid/libraries/php)
You can download latest OpenID PHP Library there.
*/
require_once "common.php";
session_start();
$errors = null;

if( isset($_POST['submit']) ){
	
	$openid = $_POST['openid_identifier'];
	
	if(empty($openid))
		$errors[] = 'Your OpenID Empty.';
	
	if(!isset($errors)){
		$consumer = getConsumer();
		// Begin the OpenID authentication process.
		$auth_request = $consumer->begin($openid);
	}
	
	// No auth request means we can't begin OpenID.
    if (!$auth_request) {
        $errors[] = 'Authentication error; not a valid OpenID.';
    }
	
	if(!isset($errors)){
		//sending requested user data
		$sreg_request = Auth_OpenID_SRegRequest::build(
										 // Required
										 array('nickname'),
										 // Optional
										 array('fullname', 'email'));
		
		if ($sreg_request) {
			$auth_request->addExtension($sreg_request);
		}
	}
	
	// Redirect the user to the OpenID server for authentication.
    // Store the token for this authentication so we can verify the
    // response.

    // For OpenID 1, send a redirect.  For OpenID 2, use a Javascript
    // form to send a POST request to the server.
	if(!isset($errors)){
		if ($auth_request->shouldSendRedirect()) {
			$redirect_url = $auth_request->redirectURL(getTrustRoot(),
													   getReturnTo());

			// If the redirect URL can't be built, display an error
			// message.
			if (Auth_OpenID::isFailure($redirect_url)) {
				$errors[] = 'Could not redirect to server: ' . $redirect_url->message;
			} else {
				// Send redirect.
				header("Location: ".$redirect_url);
			}
		} else {
			// Generate form markup and render it.
			$form_id = 'openid_message';
			$form_html = $auth_request->htmlMarkup(getTrustRoot(), getReturnTo(),
												   false, array('id' => $form_id));

			// Display an error if the form markup couldn't be generated;
			// otherwise, render the HTML.
			if (Auth_OpenID::isFailure($form_html)) {
				$errors[] = 'Could not redirect to server: ' . $form_html->message;
			} else {
				print $form_html;
				exit;
			}
		}
	}
}

if( isset($_SESSION['openid']) )
	header('Location:home.php?');
?>
<html>
<head><title>PHP OpenID</title></head>
  
<body>
<?php
if( isset($errors) ){
	foreach( $errors as $error){
		echo $error.'<br />';
	}
}
?>
<form method="post" action="">
 OpenID URL:
<input type="hidden" name="action" value="verify" />
<input type="text" name="openid_identifier" value="" />
<input type="submit" name="submit" value="Login" />
</form>
</div>
</body>
</html>