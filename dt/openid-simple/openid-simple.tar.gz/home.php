<?php
/*
This script writen and modified by kandar (iskandarsoesman@gmail.com) at August 2009
Feel free to modified with your own risk.
Visit my blog at www.kandar.info for more stuffs.

Original soruce writen by JanRain
(http://www.openidenabled.com/openid/libraries/php)
You can download latest OpenID PHP Library there.
*/

session_start();
if(empty($_SESSION) || !isset($_SESSION) )
	header('Location:index.php');

if(isset($_GET['logout'])){
	session_destroy();
	header('Location:index.php');
}
else{
	$openid = $_SESSION['openid'];
?>
<html>
<head><title>Welcome <?php echo $openid;?></title></head>
<body>
	Selamat datang <?php echo $openid;?> <a href="?logout">Logout</a>
</body>
</html>
<?php
}
?>