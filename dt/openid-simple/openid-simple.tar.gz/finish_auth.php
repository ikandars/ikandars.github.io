<?php
/*
This script writen and modified by kandar (iskandarsoesman@gmail.com) at August 2009
Feel free to modified with your own risk.
Visit my blog at www.kandar.info for more stuffs.

Original soruce writen by JanRain
(http://www.openidenabled.com/openid/libraries/php)
You can download latest OpenID PHP Library there.
*/

require_once "common.php";
session_start();

function escape($thing) {
    return htmlentities($thing);
}

function run() {
    $consumer = getConsumer();

    // Complete the authentication process using the server's
    // response.
    $return_to = getReturnTo();
    $response = $consumer->complete($return_to);

    // Check the response status.
    if ($response->status == Auth_OpenID_CANCEL) {
        // This means the authentication was cancelled.
        exit('Verification cancelled.');
    }
	else if ($response->status == Auth_OpenID_FAILURE) {
        // Authentication failed; display the error message.
        exit('OpenID authentication failed: ' . $response->message);
    }
	else if ($response->status == Auth_OpenID_SUCCESS) {
        // This means the authentication succeeded; extract the
        // identity URL and Simple Registration data (if it was
        // returned).
        $openid = $response->getDisplayIdentifier();
        $esc_identity = escape($openid);

        $sreg_resp = Auth_OpenID_SRegResponse::fromSuccessResponse($response);
        $sreg = $sreg_resp->contents();
		do_login($esc_identity, $sreg);
    }
}

function do_login($openid, $sreg = null){
	session_start();
	$_SESSION['openid'] = $openid;
	header('Location:home.php?');
}

run();

?>